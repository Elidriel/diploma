export * from "./icon.component";
