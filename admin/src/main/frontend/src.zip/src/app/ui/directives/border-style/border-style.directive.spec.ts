import { TcBorderStyleDirective } from "./border-style.directive";

describe("TcBorderStyleDirective", () => {
  it("should create an instance", () => {
    const directive = new TcBorderStyleDirective();
    expect(directive).toBeTruthy();
  });
});
