import { TCBgColorDirective } from "./bg-color.directive";

describe("TCBgColorDirective", () => {
  it("should create an instance", () => {
    const directive = new TCBgColorDirective();
    expect(directive).toBeTruthy();
  });
});
