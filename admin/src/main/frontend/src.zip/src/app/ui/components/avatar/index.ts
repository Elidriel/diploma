export * from "./avatar.component";
