import { TCShapeDirective } from "./shape.directive";

describe("TCShapeDirective", () => {
  it("should create an instance", () => {
    const directive = new TCShapeDirective();
    expect(directive).toBeTruthy();
  });
});
