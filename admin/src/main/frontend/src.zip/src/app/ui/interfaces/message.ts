export interface Message {
  date: string;
  content: any;
  my: boolean;
}
