export * from "./card.component";
