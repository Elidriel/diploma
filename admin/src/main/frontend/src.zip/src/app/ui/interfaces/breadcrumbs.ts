export interface Breadcrumb {
  title: string;
  icon?: string;
  route?: string;
}
