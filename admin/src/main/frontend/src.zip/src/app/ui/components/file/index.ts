export * from "./file.component";
