export * from "./badge.component";
