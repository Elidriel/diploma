import { TcGradientDirective } from "./gradient.directive";

describe("TcGradientDirective", () => {
  it("should create an instance", () => {
    const directive = new TcGradientDirective();
    expect(directive).toBeTruthy();
  });
});
