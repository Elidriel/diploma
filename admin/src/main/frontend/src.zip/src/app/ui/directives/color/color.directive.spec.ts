import { TCColorDirective } from "./color.directive";

describe("TcColorDirective", () => {
  it("should create an instance", () => {
    const directive = new TCColorDirective();
    expect(directive).toBeTruthy();
  });
});
