export * from "./rating.component";
