export class SizeDto {

	id: number;
	value: number;

	constructor(id: number, value: number) {
		this.id = id;
		this.value = value;
	}

}