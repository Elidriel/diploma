export class CategoryDto {

	id: number;
	name: string;
	imageId: string;
	parentCategory: CategoryDto;

	constructor(id: number, name: string, imageId: string, parentCategory: CategoryDto) {
		this.id = id;
		this.name = name;
		this.imageId = imageId;
		this.parentCategory = parentCategory;
	}

}